# -*- coding: utf-8 -*-

from . import maintenance_request
from . import maintenance_request_material
from . import maintenance_equipment
from . import equipment_checklist
from . import maintenance_equipment_checklist
from . import project_task
from . import material_purchase_requisition
from . import maintenance_planned_material

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
